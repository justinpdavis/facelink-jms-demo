namespace JmsFaceLab;

/// <summary>
/// Application workflow. The engine only proposes candidate records; all identity links
/// require an explicit operator action. No person is identified automatically.
/// </summary>
public sealed class AppService(XmlStore store, FaceEngine engine, IWebHostEnvironment environment)
{
    public object Status()
    {
        var db = store.Snapshot();
        return new
        {
            modelsReady = engine.ModelsPresent,
            people = db.People.Count,
            enrolledPeople = db.EnrolledFaces.Select(e => e.PersonId).Distinct().Count(),
            enrolledPhotos = db.EnrolledFaces.Count,
            submissions = db.Submissions.Count,
            pendingBatch = db.BatchQueue.Count(b => b.Status is "ready" or "possible-duplicate"),
            threshold = FaceEngine.ReviewThreshold,
            environment = "DEMO / Not approved for operational identification"
        };
    }

    public object People(string? search = null)
    {
        var db = store.Snapshot();
        var list = db.People.AsEnumerable();
        if (!string.IsNullOrWhiteSpace(search))
            list = list.Where(p => p.Name.Contains(search, StringComparison.OrdinalIgnoreCase)
                                 || p.PersonId.Contains(search, StringComparison.OrdinalIgnoreCase)
                                 || p.BookingId.Contains(search, StringComparison.OrdinalIgnoreCase));
        return list.OrderBy(p => p.PersonId).Take(150).Select(p => new
        {
            p.PersonId, p.Name, p.BookingId, p.Facility, p.PhotoUrl,
            p.Status, p.Source, p.Demo,
            enrolled = db.EnrolledFaces.Count(x => x.PersonId == p.PersonId)
        }).ToList();
    }

    public object Submissions()
    {
        var db = store.Snapshot();
        return db.Submissions.OrderByDescending(x => x.CreatedAt).Take(100).Select(x => DisplaySubmission(x)).ToList();
    }

    public object? Submission(string id)
    {
        var record = store.Snapshot().Submissions.FirstOrDefault(s => s.SubmissionId == id);
        return record is null ? null : DisplaySubmission(record);
    }

    private static object DisplaySubmission(SubmissionRecord s) => new
    {
        s.SubmissionId, s.Note, s.Source, s.CreatedAt, s.Status,
        photoUrl = $"/api/media/{s.OriginalMediaId}",
        faces = s.Faces.Select(f => new
        {
            f.FaceId, f.X, f.Y, f.Width, f.Height,
            photoUrl = $"/api/media/{f.MediaId}",
            candidates = f.Candidates.Select(c => new { c.PersonId, c.Name, c.PortraitUrl, c.Similarity })
        }).ToList()
    };

    public async Task<object> CreateSubmissionAsync(byte[] jpeg, string? note, CancellationToken ct)
    {
        // JPG conversion happens client-side, but validate independently at the server.
        if (jpeg.Length < 64 || jpeg.Length > 12 * 1024 * 1024 || jpeg[0] != 0xFF || jpeg[1] != 0xD8)
            throw new InvalidDataException("Upload a JPEG image under 12 MB.");

        string mediaId = store.SaveMedia(jpeg);
        var submission = new SubmissionRecord
        {
            SubmissionId = "S-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
            OriginalMediaId = mediaId,
            Note = (note ?? "").Trim()[..Math.Min((note ?? "").Trim().Length, 500)],
            CreatedAt = DateTimeOffset.UtcNow.ToString("O"),
            Status = engine.ModelsPresent ? "Analyzing" : "Pending models"
        };
        store.Update(db => { db.Submissions.Add(submission); return 0; });
        if (engine.ModelsPresent) return await AnalyzeSubmissionAsync(submission.SubmissionId, ct);
        return DisplaySubmission(submission);
    }

    public async Task<object> AnalyzeSubmissionAsync(string submissionId, CancellationToken ct)
    {
        var submission = store.Snapshot().Submissions.FirstOrDefault(s => s.SubmissionId == submissionId)
                         ?? throw new KeyNotFoundException("Submission not found.");
        var photo = store.ReadMedia(submission.OriginalMediaId)
                    ?? throw new FileNotFoundException("Submission image missing.");
        var faces = await engine.AnalyzeAsync(photo, ct);
        var enrolled = store.Snapshot();
        var observations = new List<ObservedFace>();
        foreach (var f in faces)
        {
            var cropId = store.SaveMedia(f.PortraitJpeg);
            observations.Add(new ObservedFace
            {
                FaceId = "F-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
                MediaId = cropId,
                X = f.X, Y = f.Y, Width = f.Width, Height = f.Height,
                EmbeddingBase64 = FaceEngine.Encode(f.Embedding),
                Candidates = Rank(f.Embedding, enrolled)
            });
        }
        return store.Update(db =>
        {
            var current = db.Submissions.First(x => x.SubmissionId == submissionId);
            current.Faces = observations;
            current.Status = observations.Count == 0 ? "No faces detected" : "Review candidates";
            return DisplaySubmission(current);
        });
    }

    private static List<MatchCandidate> Rank(float[] embedding, FaceDatabase db)
    {
        return db.EnrolledFaces.Where(x => x.EmbeddingBase64.Length > 0)
            .Select(e => new { e.PersonId, Score = FaceEngine.Similarity(embedding, FaceEngine.Decode(e.EmbeddingBase64)) })
            .Where(s => s.Score >= FaceEngine.ReviewThreshold)
            .GroupBy(x => x.PersonId)
            .Select(g => new { PersonId = g.Key, Score = g.Max(x => x.Score) })
            .OrderByDescending(x => x.Score).Take(3)
            .Select(x =>
            {
                var p = db.People.FirstOrDefault(p => p.PersonId == x.PersonId);
                return new MatchCandidate
                {
                    PersonId = x.PersonId,
                    Name = p?.Name ?? "Unknown record",
                    PortraitUrl = db.EnrolledFaces.First(e => e.PersonId == x.PersonId).PortraitUrl,
                    Similarity = Math.Round(x.Score, 3)
                };
            }).ToList();
    }

    public object Enroll(EnrollRequest request)
    {
        if (!request.OperatorReviewed || string.IsNullOrWhiteSpace(request.ReviewedBy))
            throw new ArgumentException("An operator must review the photo and record their name before enrollment.");
        var state = store.Snapshot();
        var observed = state.Submissions.SelectMany(s => s.Faces).FirstOrDefault(f => f.FaceId == request.FaceId)
                       ?? throw new KeyNotFoundException("Face not found in any submission.");
        return store.Update(db =>
        {
            string personId = (request.PersonId ?? "").Trim();
            PersonRecord? person = null;
            if (personId.Length > 0)
            {
                person = db.People.FirstOrDefault(p => p.PersonId == personId)
                         ?? throw new KeyNotFoundException("Selected JMS person was not found.");
            }
            else
            {
                personId = "FIELD-" + Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
                person = new PersonRecord
                {
                    PersonId = personId,
                    Name = string.IsNullOrWhiteSpace(request.Name) ? "Unidentified field subject " + personId[^4..] : request.Name.Trim()[..Math.Min(100, request.Name.Trim().Length)],
                    BookingId = "", Facility = "Field intake", Source = "Officer-submitted photograph",
                    Status = "Unverified field record", Demo = false,
                    PhotoUrl = $"/api/media/{observed.MediaId}",
                    CreatedAt = DateTimeOffset.UtcNow.ToString("O")
                };
                db.People.Add(person);
            }
            if (db.EnrolledFaces.Any(e => e.FaceId == observed.FaceId))
                throw new ArgumentException("This face has already been enrolled.");
            db.EnrolledFaces.Add(new EnrollmentRecord
            {
                EnrollmentId = "E-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
                PersonId = personId, FaceId = observed.FaceId,
                PortraitUrl = $"/api/media/{observed.MediaId}",
                EmbeddingBase64 = observed.EmbeddingBase64,
                Source = "Field submission", ReviewedBy = request.ReviewedBy.Trim(),
                EnrolledAt = DateTimeOffset.UtcNow.ToString("O"),
                VerificationStatus = person.Status == "Unverified field record" ? "Identity unverified" : "Operator linked to JMS record"
            });
            return new { person.PersonId, person.Name, person.Status, person.PhotoUrl, message = "Face enrolled with operator review; identity is not automatically verified." };
        });
    }

    public async Task<object> ScanBatchAsync(CancellationToken ct)
    {
        if (!engine.ModelsPresent) throw new InvalidOperationException("ONNX models not installed. Run scripts/download-models.ps1 first.");
        var db = store.Snapshot();
        var list = new List<BatchRecord>();
        foreach (var person in db.People.Where(p => p.Demo).OrderBy(p => p.PersonId))
        {
            ct.ThrowIfCancellationRequested();
            if (db.EnrolledFaces.Any(e => e.PersonId == person.PersonId))
            {
                list.Add(new BatchRecord { PersonId = person.PersonId, Status = "already-enrolled" });
                continue;
            }
            // This prototype reads images from a local, generated demo JMS photo directory.
            if (!person.PhotoUrl.StartsWith("/demo/", StringComparison.Ordinal)) continue;
            var file = Path.Combine(environment.WebRootPath, "demo", Path.GetFileName(person.PhotoUrl));
            if (!File.Exists(file)) continue;
            var photos = await engine.AnalyzeAsync(await File.ReadAllBytesAsync(file, ct), ct);
            if (photos.Count != 1)
            {
                list.Add(new BatchRecord { PersonId = person.PersonId, Status = "no-face" });
                continue;
            }
            var best = Rank(photos[0].Embedding, db).FirstOrDefault();
            list.Add(new BatchRecord
            {
                PersonId = person.PersonId,
                Status = best is null ? "ready" : "possible-duplicate",
                EmbeddingBase64 = FaceEngine.Encode(photos[0].Embedding),
                PossiblePersonId = best?.PersonId ?? "",
                Similarity = best?.Similarity ?? 0,
                ScannedAt = DateTimeOffset.UtcNow.ToString("O")
            });
        }
        store.Update(d => { d.BatchQueue = list; return 0; });
        return BatchQueue();
    }

    public object BatchQueue()
    {
        var db = store.Snapshot();
        var results = db.BatchQueue.Select(q =>
        {
            var p = db.People.FirstOrDefault(p => p.PersonId == q.PersonId);
            return new { q.PersonId, name = p?.Name ?? "Unknown", photoUrl = p?.PhotoUrl ?? "", q.Status, q.PossiblePersonId, q.Similarity };
        }).ToList();
        return new
        {
            total = results.Count,
            ready = results.Count(x => x.Status == "ready"),
            possibleDuplicates = results.Count(x => x.Status == "possible-duplicate"),
            alreadyEnrolled = results.Count(x => x.Status == "already-enrolled"),
            noFace = results.Count(x => x.Status == "no-face"),
            items = results
        };
    }

    public object BatchEnroll(BatchEnrollRequest request)
    {
        if (!request.OperatorReviewed || string.IsNullOrWhiteSpace(request.ReviewedBy))
            throw new ArgumentException("Batch enrollment requires recorded operator review.");
        var ids = request.PersonIds.Distinct().Take(100).ToHashSet(StringComparer.Ordinal);
        if (ids.Count == 0) throw new ArgumentException("Select one or more ready items first.");
        return store.Update(db =>
        {
            var enrolled = new List<string>();
            var skipped = new List<string>();
            foreach (var item in db.BatchQueue.Where(x => ids.Contains(x.PersonId)))
            {
                if (item.Status != "ready" || string.IsNullOrEmpty(item.EmbeddingBase64) ||
                    db.EnrolledFaces.Any(e => e.PersonId == item.PersonId))
                { skipped.Add(item.PersonId); continue; }
                var p = db.People.FirstOrDefault(x => x.PersonId == item.PersonId);
                if (p is null) { skipped.Add(item.PersonId); continue; }
                // Re-evaluate against prior entries in this same enrollment operation.
                // A plausible duplicate is held for manual case-by-case review.
                if (Rank(FaceEngine.Decode(item.EmbeddingBase64), db).Any())
                { item.Status = "possible-duplicate"; skipped.Add(item.PersonId); continue; }
                db.EnrolledFaces.Add(new EnrollmentRecord
                {
                    EnrollmentId = "E-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
                    PersonId = item.PersonId,
                    PortraitUrl = p.PhotoUrl,
                    EmbeddingBase64 = item.EmbeddingBase64,
                    FaceId = "JMS-HEADSHOT-" + item.PersonId,
                    Source = "Demo JMS batch", ReviewedBy = request.ReviewedBy.Trim(),
                    EnrolledAt = DateTimeOffset.UtcNow.ToString("O"),
                    VerificationStatus = "Operator batch-reviewed JMS reference"
                });
                item.Status = "already-enrolled";
                enrolled.Add(item.PersonId);
            }
            return new { enrolled = enrolled.Count, skipped = skipped.Count, enrolledIds = enrolled, skippedIds = skipped };
        });
    }
}
