using System.Runtime.InteropServices;
using OpenCvSharp;

namespace JmsFaceLab;

/// <summary>
/// Local OpenCV YuNet face detector + SFace feature extractor.
/// Produces review candidates only; similarity is NOT an identity probability.
/// </summary>
public sealed class FaceEngine : IDisposable
{
    // Illustrative review cutoff, not validated for jail populations or 1:N identification.
    public const double ReviewThreshold = 0.52;
    private readonly string _detectorModel;
    private readonly string _recognitionModel;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private FaceDetectorYN? _detector;
    private FaceRecognizerSF? _recognizer;

    public FaceEngine(IWebHostEnvironment env)
    {
        var models = Path.Combine(env.ContentRootPath, "Models");
        _detectorModel = Path.Combine(models, "face_detection_yunet_2026may.onnx");
        _recognitionModel = Path.Combine(models, "face_recognition_sface_2021dec.onnx");
    }

    public bool ModelsPresent => File.Exists(_detectorModel) && File.Exists(_recognitionModel);

    public async Task<List<DetectedFace>> AnalyzeAsync(byte[] photo, CancellationToken ct = default)
    {
        if (!ModelsPresent) throw new InvalidOperationException("Install the OpenCV YuNet and SFace ONNX model files using scripts/download-models.ps1 first.");
        await _gate.WaitAsync(ct);
        try
        {
            _detector ??= FaceDetectorYN.Create(_detectorModel, "", new OpenCvSharp.Size(320, 320), scoreThreshold: 0.72f);
            _recognizer ??= FaceRecognizerSF.Create(_recognitionModel, "");
            using var source = Cv2.ImDecode(photo, ImreadModes.Color);
            if (source.Empty()) throw new InvalidDataException("Image could not be decoded. Use JPG or PNG; HEIC images should be converted to JPG in the browser.");
            if ((long)source.Width * source.Height > 25_000_000) throw new InvalidDataException("Image exceeds 25 megapixels.");
            // Make DNN analysis predictable on high-resolution smartphone photographs.
            double ratio = Math.Min(1d, 1600d / Math.Max(source.Width, source.Height));
            using var frame = new Mat();
            // Dynamic YuNet ONNX expects dimensions divisible by 32.
            int newWidth = Math.Max(32, (int)Math.Ceiling(source.Width * ratio / 32d) * 32);
            int newHeight = Math.Max(32, (int)Math.Ceiling(source.Height * ratio / 32d) * 32);
            if (newWidth != source.Width || newHeight != source.Height)
                Cv2.Resize(source, frame, new OpenCvSharp.Size(newWidth, newHeight));
            else source.CopyTo(frame);

            _detector.SetInputSize(frame.Size());
            using var detection = new Mat();
            _detector.Detect(frame, detection);
            var result = new List<DetectedFace>();
            if (detection.Empty()) return result;
            for (int i = 0; i < detection.Rows && result.Count < 30; i++)
            {
                using var row = detection.Row(i);
                var x = (int)Math.Round(row.At<float>(0, 0));
                var y = (int)Math.Round(row.At<float>(0, 1));
                var width = (int)Math.Round(row.At<float>(0, 2));
                var height = (int)Math.Round(row.At<float>(0, 3));
                if (width <= 0 || height <= 0) continue;

                // SFace uses landmarks from this row for aligned feature extraction.
                using var aligned = new Mat();
                using var feature = new Mat();
                _recognizer.AlignCrop(frame, row, aligned);
                _recognizer.Feature(aligned, feature);
                var size = checked(feature.Rows * feature.Cols * feature.Channels());
                var embedding = new float[size];
                if (!feature.IsContinuous()) throw new InvalidOperationException("SFace feature matrix is not continuous.");
                Marshal.Copy(feature.Data, embedding, 0, size);
                Normalize(embedding);

                // Save a slightly padded image crop rather than the aligned ML input.
                int padX = Math.Max(4, width / 6), padY = Math.Max(4, height / 6);
                int left = Math.Clamp(x - padX, 0, frame.Width - 1);
                int top = Math.Clamp(y - padY, 0, frame.Height - 1);
                int right = Math.Clamp(x + width + padX, left + 1, frame.Width);
                int bottom = Math.Clamp(y + height + padY, top + 1, frame.Height);
                using var region = new Mat(frame, new Rect(left, top, right - left, bottom - top));
                Cv2.ImEncode(".jpg", region, out var cropJpeg);
                result.Add(new DetectedFace
                {
                    X = x, Y = y, Width = width, Height = height,
                    Embedding = embedding,
                    PortraitJpeg = cropJpeg
                });
            }
            return result;
        }
        finally { _gate.Release(); }
    }

    public static string Encode(float[] embedding)
    {
        var bytes = new byte[embedding.Length * sizeof(float)];
        Buffer.BlockCopy(embedding, 0, bytes, 0, bytes.Length);
        return Convert.ToBase64String(bytes);
    }

    public static float[] Decode(string encoded)
    {
        var data = Convert.FromBase64String(encoded);
        if (data.Length % 4 != 0) throw new InvalidDataException("Invalid stored face vector.");
        var floats = new float[data.Length / 4];
        Buffer.BlockCopy(data, 0, floats, 0, data.Length);
        return floats;
    }

    public static double Similarity(float[] a, float[] b)
    {
        if (a.Length != b.Length || a.Length == 0) return -1;
        double dot = 0, x = 0, y = 0;
        for (var i = 0; i < a.Length; i++) { dot += (double)a[i] * b[i]; x += (double)a[i] * a[i]; y += (double)b[i] * b[i]; }
        return x <= 0 || y <= 0 ? -1 : dot / Math.Sqrt(x * y);
    }

    private static void Normalize(float[] v)
    {
        double sum = 0;
        foreach (var f in v) sum += (double)f * f;
        var mag = Math.Sqrt(sum);
        if (mag > 0) for (var i = 0; i < v.Length; i++) v[i] = (float)(v[i] / mag);
    }

    public void Dispose() { _detector?.Dispose(); _recognizer?.Dispose(); _gate.Dispose(); }
}
