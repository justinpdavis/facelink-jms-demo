using System.Xml.Serialization;

namespace JmsFaceLab;

// XML file is a prototype persistence layer, NOT a production JMS record store.
[XmlRoot("jmsFaceLab")]
public sealed class FaceDatabase
{
    [XmlArray("people"), XmlArrayItem("person")]
    public List<PersonRecord> People { get; set; } = [];

    [XmlArray("enrolledFaces"), XmlArrayItem("enrolledFace")]
    public List<EnrollmentRecord> EnrolledFaces { get; set; } = [];

    [XmlArray("submissions"), XmlArrayItem("submission")]
    public List<SubmissionRecord> Submissions { get; set; } = [];

    [XmlArray("batchQueue"), XmlArrayItem("item")]
    public List<BatchRecord> BatchQueue { get; set; } = [];

    [XmlArray("mediaFiles"), XmlArrayItem("file")]
    public List<MediaRecord> MediaFiles { get; set; } = [];
}

public sealed class PersonRecord
{
    public string PersonId { get; set; } = "";
    public string Name { get; set; } = "";
    public string BookingId { get; set; } = "";
    public string Facility { get; set; } = "";
    public string PhotoUrl { get; set; } = "";
    public string Source { get; set; } = "";
    public string Status { get; set; } = "Demo person";
    public string CreatedAt { get; set; } = "";
    public bool Demo { get; set; }
}

public sealed class EnrollmentRecord
{
    public string EnrollmentId { get; set; } = "";
    public string PersonId { get; set; } = "";
    public string FaceId { get; set; } = "";
    public string PortraitUrl { get; set; } = "";
    public string EmbeddingBase64 { get; set; } = "";
    public string Source { get; set; } = "";
    public string ReviewedBy { get; set; } = "";
    public string EnrolledAt { get; set; } = "";
    public string VerificationStatus { get; set; } = "Operator reviewed";
}

public sealed class SubmissionRecord
{
    public string SubmissionId { get; set; } = "";
    public string OriginalMediaId { get; set; } = "";
    public string Note { get; set; } = "";
    public string Source { get; set; } = "Field capture";
    public string CreatedAt { get; set; } = "";
    public string Status { get; set; } = "Pending analysis";
    [XmlArray("faces"), XmlArrayItem("face")]
    public List<ObservedFace> Faces { get; set; } = [];
}

public sealed class ObservedFace
{
    public string FaceId { get; set; } = "";
    public string MediaId { get; set; } = "";
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public string EmbeddingBase64 { get; set; } = "";
    [XmlArray("candidates"), XmlArrayItem("candidate")]
    public List<MatchCandidate> Candidates { get; set; } = [];
}

public sealed class MatchCandidate
{
    public string PersonId { get; set; } = "";
    public string Name { get; set; } = "";
    public string PortraitUrl { get; set; } = "";
    public double Similarity { get; set; }
}

public sealed class BatchRecord
{
    public string PersonId { get; set; } = "";
    // ready, possible-duplicate, no-face, already-enrolled
    public string Status { get; set; } = "";
    public string EmbeddingBase64 { get; set; } = "";
    public string PossiblePersonId { get; set; } = "";
    public double Similarity { get; set; }
    public string ScannedAt { get; set; } = "";
}

public sealed class MediaRecord
{
    public string MediaId { get; set; } = "";
    public string FileName { get; set; } = "";
    public string Mime { get; set; } = "image/jpeg";
}

public sealed class EnrollRequest
{
    public string FaceId { get; set; } = "";
    public string? PersonId { get; set; }
    public string? Name { get; set; }
    public string ReviewedBy { get; set; } = "";
    public bool OperatorReviewed { get; set; }
}

public sealed class BatchEnrollRequest
{
    public List<string> PersonIds { get; set; } = [];
    public string ReviewedBy { get; set; } = "";
    public bool OperatorReviewed { get; set; }
}

public sealed class DetectedFace
{
    public required float[] Embedding { get; init; }
    public required byte[] PortraitJpeg { get; init; }
    public int X { get; init; }
    public int Y { get; init; }
    public int Width { get; init; }
    public int Height { get; init; }
}
