# ONNX model files

This project requires two open-source OpenCV Zoo models for detection and candidate search:

- face_detection_yunet_2026may.onnx — dynamic-shape detector (SHA-256: ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0)
- face_recognition_sface_2021dec.onnx — SFace feature extractor (SHA-256: 0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79)

On Windows, run `powershell -ExecutionPolicy Bypass -File scripts/download-models.ps1` from the project root. The actual binaries are not part of the distributed ZIP.
