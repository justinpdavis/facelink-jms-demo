using System.Text.Json;
using JmsFaceLab;

var builder = WebApplication.CreateBuilder(args);
builder.Services.ConfigureHttpJsonOptions(opt =>
    opt.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase);
builder.Services.AddSingleton<XmlStore>();
builder.Services.AddSingleton<FaceEngine>();
builder.Services.AddSingleton<AppService>();
builder.WebHost.ConfigureKestrel(options => options.Limits.MaxRequestBodySize = 12 * 1024 * 1024);

var app = builder.Build();

// Simple demo-only protection for the public HTTPS endpoint. This is not a
// corrections-grade identity/security system: production use requires SSO,
// per-user audit trails, MFA, facility authorization, and secure storage.
var demoPassword = app.Configuration["FACELINK_DEMO_PASSWORD"];
var demoUsername = app.Configuration["FACELINK_DEMO_USERNAME"] ?? "demo";
if (app.Environment.IsProduction() && string.IsNullOrWhiteSpace(demoPassword))
    throw new InvalidOperationException("Set FACELINK_DEMO_PASSWORD before exposing this demo publicly.");

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
app.Use(async (ctx, next) =>
{
    // Unauthenticated health check reveals no sensitive data.
    if (ctx.Request.Path == "/health" || string.IsNullOrEmpty(demoPassword))
    {
        await next();
        return;
    }
    var authorized = false;
    var hdr = ctx.Request.Headers.Authorization.ToString();
    if (hdr.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
    {
        try
        {
            var supplied = System.Text.Encoding.UTF8.GetString(
                Convert.FromBase64String(hdr[6..].Trim()));
            var pair = supplied.Split(':', 2);
            if (pair.Length == 2 && pair[0] == demoUsername)
            {
                var received = System.Text.Encoding.UTF8.GetBytes(pair[1]);
                var expected = System.Text.Encoding.UTF8.GetBytes(demoPassword);
                authorized = received.Length == expected.Length &&
                    System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(received, expected);
            }
        }
        catch (FormatException) { /* Invalid basic-auth header */ }
    }
    if (!authorized)
    {
        ctx.Response.Headers.WWWAuthenticate = "Basic realm=\"FaceLink demo\"";
        ctx.Response.Headers.CacheControl = "no-store";
        ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await ctx.Response.WriteAsync("Authentication required for synthetic-data demo.");
        return;
    }
    ctx.Response.Headers.CacheControl = "no-store";
    await next();
});
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/status", (AppService svc) => Results.Ok(svc.Status()));
app.MapGet("/api/people", (AppService svc, string? search) => Results.Ok(svc.People(search)));
app.MapGet("/api/submissions", (AppService svc) => Results.Ok(svc.Submissions()));
app.MapGet("/api/submissions/{id}", (AppService svc, string id) =>
    svc.Submission(id) is { } result ? Results.Ok(result) : Results.NotFound());
app.MapGet("/api/batch", (AppService svc) => Results.Ok(svc.BatchQueue()));

app.MapGet("/api/media/{id}", (XmlStore store, string id) =>
{
    var file = store.ReadMedia(id);
    return file is null ? Results.NotFound() : Results.File(file, "image/jpeg", enableRangeProcessing: false);
});

app.MapPost("/api/submissions", async (HttpRequest request, AppService svc, CancellationToken ct) =>
{
    try
    {
        if (!request.HasFormContentType) return Results.BadRequest(new { error = "Upload multipart form data." });
        var form = await request.ReadFormAsync(ct);
        var upload = form.Files.GetFile("photo");
        if (upload is null || upload.Length == 0 || upload.Length > 12 * 1024 * 1024)
            return Results.BadRequest(new { error = "Choose a photo smaller than 12 MB." });
        using var mem = new MemoryStream();
        await upload.CopyToAsync(mem, ct);
        var result = await svc.CreateSubmissionAsync(mem.ToArray(), form["note"].ToString(), ct);
        return Results.Ok(result);
    }
    catch (Exception ex) { return ToFailure(ex); }
});

app.MapPost("/api/submissions/{id}/analyze", async (AppService svc, string id, CancellationToken ct) =>
{
    try { return Results.Ok(await svc.AnalyzeSubmissionAsync(id, ct)); }
    catch (Exception ex) { return ToFailure(ex); }
});

app.MapPost("/api/enroll", (AppService svc, EnrollRequest request) =>
{
    try { return Results.Ok(svc.Enroll(request)); }
    catch (Exception ex) { return ToFailure(ex); }
});

app.MapPost("/api/batch/scan", async (AppService svc, CancellationToken ct) =>
{
    try { return Results.Ok(await svc.ScanBatchAsync(ct)); }
    catch (Exception ex) { return ToFailure(ex); }
});

app.MapPost("/api/batch/enroll", (AppService svc, BatchEnrollRequest request) =>
{
    try { return Results.Ok(svc.BatchEnroll(request)); }
    catch (Exception ex) { return ToFailure(ex); }
});

app.Run();

static IResult ToFailure(Exception ex)
{
    int status = ex switch
    {
        KeyNotFoundException or FileNotFoundException => 404,
        InvalidOperationException when ex.Message.Contains("model", StringComparison.OrdinalIgnoreCase) => 503,
        ArgumentException or InvalidDataException => 400,
        OperationCanceledException => 499,
        _ => 500
    };
    // Prototype error reporting; redact internal details and paths before production use.
    return Results.Json(new { error = status == 500 ? "Processing failed. Check the server log." : ex.Message }, statusCode: status);
}
