# FaceLink Manual QA Checklist

Run after installing .NET 11 and downloading/verifying the two ONNX files. These are **not** automated test results.

- [ ] `dotnet restore` and `dotnet build` succeed on the Windows development PC.
- [ ] Opening `http://localhost:5072` shows a chat intake and the model indicator says "Face engine ready".
- [ ] Tap **Try a 3-person demo photograph**, then **Submit photo**. More than one face should be extracted (the exact count depends on detector/version).
- [ ] Before enrolling any headshots, no identity is automatically confirmed.
- [ ] Open **Batch enrollment**, scan 100 JMS examples, inspect review queue.
- [ ] Explicitly approve several ready records; confirm they appear as enrolled in the repository.
- [ ] Submit the same original demo portrait used for an enrolled person. Confirm a candidate appears with name, photograph and a raw similarity score (not a percentage).
- [ ] Submit an unrecognized photo and choose **New unverified field record**; confirm it is labeled unverified.
- [ ] Upload a photo with multiple different people; review each extracted face independently.
- [ ] Re-run batch scanning. Previously enrolled people should be marked **already enrolled**.
- [ ] Restart the server; verify submissions and enrollments persist in the XML file.
- [ ] Validate mobile navigation, camera upload, and gallery upload from iOS Safari.
- [ ] Test without model files: the submission persists as **Pending models**, then **Analyze** works after models are installed.
- [ ] Test invalid files and oversized images: the server rejects unsupported or excessive uploads.

Note: Recognition accuracy cannot be established from these generated photos, and this prototype does not demonstrate suitability for correctional decision-making.
