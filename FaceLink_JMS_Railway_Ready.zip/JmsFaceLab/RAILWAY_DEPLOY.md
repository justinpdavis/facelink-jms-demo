# Deploy FaceLink to Railway — demo, no real inmate data

The source is ready to be built with a Linux-based .NET 11 Docker image. It has **not yet been built or deployed end-to-end**. The Railway account project `FaceLink-JMS-Demo` and its empty service `facelink-app` have been created, but publishing a running app still requires a GitHub source repository.

## Prerequisites

1. Create a **private** GitHub repository and commit the unpacked contents of `JmsFaceLab` to its root.
2. In Railway, connect the repository to the `facelink-app` service in the existing `FaceLink-JMS-Demo` project. Do not make a second project unless intentionally desired.
3. Set `FACELINK_DEMO_PASSWORD` to a strong random password and optionally `FACELINK_DEMO_USERNAME` (default `demo`). The service intentionally refuses to start without a password in Production.
4. Attach a persistent Railway volume at `/data` so the XML database and uploaded media survive redeployment. Mounting at `/data` does not hide the bundled demo portraits because they live under `/app/wwwroot/demo`.
5. Build and deploy using the included `Dockerfile`. Downloading face models at build time requires outgoing Internet access. The script verifies their SHA-256 hashes. A release without model binaries is not a working recognition demo.
6. Add a generated `*.up.railway.app` public domain, forwarding to container port `8080`. Use HTTPS. No real correctional data or identifiable inmate images are authorized for this demo.
7. Verify the deployment reports `SUCCESS`, and `https://<domain>/health` returns `{"status":"ok"}`. In a browser, sign in with the demo username/password and check `/api/status` reports `modelsReady: true`, `people: 100`.

## Notes

- NuGet dependency selection is RID-based: Windows uses OpenCvSharp5.Windows, while `linux-x64` uses OpenCvSharp5 with the official **headless** Linux runtime (includes OpenCV DNN). Avoid the slim runtime because it lacks DNN.
- The Dockerfile uses pinned `.NET 11` build and ASP.NET runtime images. It downloads the YuNet and SFace model weights with hash validation.
- A Railway volume is strongly recommended. Without it, submissions and enrollment records may be lost on restart or redeploy.
- HTTP Basic login is a temporary, single-password demo gate. All demo activity shares one user credential; it does not provide operational-grade authorization, biometrics governance, auditability, compliance, or chain of custody.
- Do not use this for law-enforcement decisions or operational JMS identification. Any matching suggestion requires independent verification and human review.
