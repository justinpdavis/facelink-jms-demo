# FaceLink — Standalone JMS Face Intake Prototype

**ASP.NET Core 11 / C# 15 · OpenCvSharp5 · OpenCV YuNet + SFace · XML file database · Mobile-friendly UI · Railway Docker deployment assets**

FaceLink is a **proof-of-concept only**, created for evaluation with **100 fictional demo identities and generated photorealistic ID-style portraits**. No sample identity is a real inmate. Similarity comparisons propose candidates for a human to review. They do **not** automatically establish the identity of a person, authorize detention, or alter a real jail management system.

## What is included

- Responsive, chat-like intake screen; iPhone camera/gallery upload (single photo containing multiple people)
- Original photo saved under a submission ID, with extracted, separately saved face crops
- Local, offline-after-setup YuNet face detection and SFace face embeddings
- Candidate search over a **separate enrolled-photo repository**: top-three photo/name/record suggestions and raw cosine similarity scores
- Manual enrollment linked to an existing JMS demo ID, or to a new **unverified** field record
- 100 fictional JMS records in `Data/sample-jms.xml`, plus 100 generated portrait JPEGs in `wwwroot/demo/`
- Local XML tables for people, enrolled faces, submissions, observed face metadata, batch queue, and uploaded media metadata
- Batch scan of all 100 sample images, possible-duplicate review, and explicitly approved bulk enrollment of eligible entries
- Responsive repository browser, history, model-health indicator, and stored submission messages

## 1. Prerequisites

1. Windows 11 or Windows Server with the **.NET 11 SDK** installed: https://dotnet.microsoft.com/en-us/download/dotnet/11.0
2. PowerShell and Internet access **once** to download open-source ONNX model weights and restore NuGet packages.
3. For native OpenCV on Windows, install the latest Microsoft Visual C++ x64 runtime if it is not already present. The OpenCvSharp5.Windows package provides OpenCV native binaries.

The app runs locally, without Azure, SQL Server, a cloud recognition service, or a paid API. It is not designed to be opened to the public Internet.

## 2. Start the demo on Windows

Open PowerShell or the Visual Studio terminal inside the `JmsFaceLab` folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\download-models.ps1
dotnet restore
dotnet run --urls "http://localhost:5072"
```

Open **http://localhost:5072** on your PC. Open `JmsFaceLab.csproj` directly in Visual Studio for debugging.

Model assets are *not* included in the ZIP: the YuNet model is around 230 KB and SFace around 37 MB. `download-models.ps1` retrieves the official model files and validates SHA-256 hashes. The application uses no remote API when comparing faces.

### Open from an iPhone for synthetic-data testing only

Run the server on a trusted development LAN, e.g.:

```powershell
dotnet run --urls "http://0.0.0.0:5072"
```

On your iPhone, open `http://<YOUR-WINDOWS-PC-LAN-IP>:5072`. Your phone and development PC need to be on the same Wi-Fi network; a Windows Firewall allow rule may be required. The **Camera** and **Gallery** buttons allow mobile photo submission. This HTTP LAN instruction is for generated/synthetic test images only. **Use valid HTTPS, authentication and authorization before ever handling real correctional photographs.**

## 3. Test the complete flow

1. Open **JMS batch enrollment**. Press **Scan JMS photos**. This loads and analyzes each of the 100 bundled headshots (once models are installed), without enrolling anyone.
2. Select a few **ready** records that you have reviewed and press **Enroll selected**. The server recomputes similarity to prevent enrolling newly discovered possible duplicates in the same batch. Uncertain or no-face records remain for review.
3. Open **Photo intake**. Select one of the four preview portraits on desktop or browse a JPEG from the `wwwroot/demo` folder on your phone/PC. Submit the photo. The result shows face crops and potentially matching enrolled name/portrait records.
4. Choose **Review candidate / enroll** to link the face to a specific JMS record, or choose **New unverified field record** if it cannot be independently identified. The form requires explicit operator acknowledgement.
5. Check **Face repository** and **Submission history**. All metadata persists in the preseeded `Data/jms-face-lab.xml`; incoming JPGs and extracted face crops persist in `Data/media/`.

To start over, stop the app, delete `Data/jms-face-lab.xml` and `Data/media/`, and run it again. The source `Data/sample-jms.xml` and 100 source portraits are not modified.

## Core XML structure

The preseeded XML file (also regenerated on first launch if absent) contains the following tables/elements:

```xml
<jmsFaceLab>
  <people>             <!-- 100 seeded demo identities + manually added field records -->
    <person>...</person>
  </people>
  <enrolledFaces>      <!-- JMS/person IDs, portrait URLs, model embedding, reviewer -->
    <enrolledFace>...</enrolledFace>
  </enrolledFaces>
  <submissions>        <!-- original submission, notes, observed face crops, candidates -->
    <submission>...</submission>
  </submissions>
  <batchQueue>         <!-- candidate scan results requiring officer review -->
    <item>...</item>
  </batchQueue>
  <mediaFiles>         <!-- opaque media IDs mapped to private JPG files -->
    <file>...</file>
  </mediaFiles>
</jmsFaceLab>
```

The embeddings are a Base64 representation of float arrays (128 dimensions in the standard SFace model). They are highly sensitive biometric templates; the XML storage is for synthetic demo data only.

## HTTP endpoints

| Method | Path | Function |
|---|---|---|
| GET | `/api/status` | Model readiness and repository counts |
| GET | `/api/people?search=name` | Search fictional JMS people |
| GET | `/api/submissions` | Recent submission history |
| POST | `/api/submissions` | JPEG multipart upload: `photo` and `note` |
| POST | `/api/submissions/{id}/analyze` | Retry face extraction for a stored submission |
| POST | `/api/enroll` | Manual link/enrollment with operator-reviewed acknowledgement |
| GET | `/api/batch` | Review queue |
| POST | `/api/batch/scan` | Scan the 100 demo JMS photos |
| POST | `/api/batch/enroll` | Enroll selected eligible records after operator review |
| GET | `/api/media/{id}` | Serve locally stored image by opaque media ID |

The UI uses the same-origin fetch API. No identity vectors are sent to the browser in API responses.

## Solution structure

```text
JmsFaceLab/
  JmsFaceLab.csproj          # .NET 11, OpenCvSharp5.Windows
  Program.cs                # ASP.NET Core Minimal API endpoints
  Models.cs                 # XML/DTO models
  XmlStore.cs               # Atomic XML writes and local media storage
  FaceEngine.cs             # Local YuNet detector + SFace feature extractor
  AppService.cs             # Intake, candidate rank, manual / batch enrollment
  Models/                   # Optional models downloaded by setup scripts
  Data/sample-jms.xml       # 100 fictional person/booking records
  wwwroot/index.html        # Modern responsive UI
  wwwroot/app.css
  wwwroot/app.js
  wwwroot/demo/0001..0100.jpg  # Generated photorealistic sample portraits
  scripts/download-models.ps1
  scripts/download-models.sh
```

## Recognition design and limitations

1. **Detection:** YuNet returns bounding boxes and five landmarks for each face, even for several people in one photograph.
2. **Feature extraction:** SFace aligns each detected face and creates a feature vector.
3. **Search:** cosine similarity is calculated against already enrolled face vectors only, and up to three candidates at or above `0.52` are shown. **0.52 is an example review cutoff, not a calibrated law-enforcement accuracy threshold.** Similarity is not confidence or probability. No candidate means only *none met the threshold*; it does **not** prove the person is absent.
4. **Review:** a user independently verifies JMS metadata and chooses whether to link an observed face or create an unverified record. Scanning the JMS photos does not auto-enroll.
5. **Enrollment:** additional portraits can be enrolled for an existing person. For batch enrollment, possible duplicates are excluded from automatic bulk approval.

The portrait set is generated test data (some synthetic faces may resemble each other). Camera variations, occlusion, pose, lighting, demographic performance, face quality and large-gallery false positives are not validated by this prototype. The `0.52` threshold must not be considered suitable for operational jail identification.

## Production requirements before real JMS use

- Integrate using a **read-only JMS photo source** adapter and a SQL-backed, versioned enrollment database; do not connect demo endpoints to live booking/identity mutations.
- Require authenticated, role-based access, MFA, per-facility scope, approved HTTPS, rate limits and secure session management.
- Encrypt portraits and biometric embeddings at rest; implement KMS-backed keys, tamper-evident audit trails, strict retention/deletion and export controls.
- Add photo quality checks, presentation-attack detection where appropriate, external identity verification, dual confirmation for high-impact actions, and a correction/dispute workflow.
- Independently benchmark false-match and missed-match rates across relevant populations and operating conditions before even allowing operational *candidate suggestions*.
- Review applicable privacy, CJIS, local/state biometric laws, accessibility and corrections policies with counsel and security stakeholders.
- Replace simple XML file storage with resilient transactions, monitoring, schema migrations, tests, and backup/disaster recovery.
- Never take a detention, release, disciplinary, or enforcement action solely on the basis of automated facial comparison.

## Model and third-party references

- .NET 11 (released November 10, 2026): https://devblogs.microsoft.com/dotnet/announcing-dotnet-11/
- OpenCvSharp5 Windows NuGet: https://www.nuget.org/packages/OpenCvSharp5.Windows/5.0.0.20261109
- OpenCV SFace/YuNet implementation: https://docs.opencv.org/5.0/main_modules/objdetect_dnn_face.html
- YuNet source: https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet
- SFace source: https://github.com/opencv/opencv_zoo/tree/main/models/face_recognition_sface

**Build status:** Source, data assets, scripts, and browser UI are prepared. The .NET SDK and NuGet/OpenCV models were not available in the creation runtime, so this project has **not** been compiled or run end-to-end here. Install the prerequisites above and run `dotnet restore` / `dotnet run` on a Windows development machine before evaluating it. Contact me with any build error and I can revise the project.


## Railway hosting

A Linux-compatible Dockerfile, `railway.json`, volume-aware XML storage, and a demo-only Basic Authentication gate are included. Read `RAILWAY_DEPLOY.md` before exposing a domain. **The app is not hosted or confirmed running yet; deployment requires connecting a GitHub source repository and verifying the build.**
