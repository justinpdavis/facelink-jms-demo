using System.Text.Json;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace JmsFaceLab;

public sealed class XmlStore
{
    private static readonly XmlSerializer Xml = new(typeof(FaceDatabase));
    private static readonly JsonSerializerOptions CloningOptions = new() { PropertyNameCaseInsensitive = true };
    private readonly object _sync = new();
    private readonly string _dataDirectory;
    private readonly string _dbPath;
    private FaceDatabase _db;

    public XmlStore(IWebHostEnvironment env)
    {
        // A cloud volume can be mounted at /data. The original demo JMS seed
        // remains in the application image, outside the mounted volume.
        _dataDirectory = Environment.GetEnvironmentVariable("JMS_DATA_DIR")
            ?? Path.Combine(env.ContentRootPath, "Data");
        _dbPath = Path.Combine(_dataDirectory, "jms-face-lab.xml");
        Directory.CreateDirectory(Path.Combine(_dataDirectory, "media"));
        if (File.Exists(_dbPath))
        {
            using var input = File.OpenRead(_dbPath);
            _db = (FaceDatabase?)Xml.Deserialize(input) ?? new FaceDatabase();
        }
        else
        {
            _db = new FaceDatabase { People = LoadDemoPeople(Path.Combine(env.ContentRootPath, "Data", "sample-jms.xml")) };
            SaveUnderLock();
        }
    }

    private static List<PersonRecord> LoadDemoPeople(string path)
    {
        var document = XDocument.Load(path);
        return document.Root?.Elements("person").Select(x => new PersonRecord
        {
            PersonId = (string?)x.Element("personId") ?? "",
            Name = (string?)x.Element("name") ?? "",
            BookingId = (string?)x.Element("bookingId") ?? "",
            Facility = (string?)x.Element("facility") ?? "",
            PhotoUrl = (string?)x.Element("photoUrl") ?? "",
            Source = "Demo JMS",
            Status = "Fictional sample",
            CreatedAt = (string?)x.Element("createdAt") ?? DateTimeOffset.UtcNow.ToString("O"),
            Demo = true
        }).ToList() ?? [];
    }

    public FaceDatabase Snapshot()
    {
        lock (_sync)
        {
            // Provide an isolated snapshot so request handlers cannot mutate the store directly.
            return JsonSerializer.Deserialize<FaceDatabase>(JsonSerializer.Serialize(_db, CloningOptions), CloningOptions)!;
        }
    }

    public T Update<T>(Func<FaceDatabase, T> update)
    {
        lock (_sync)
        {
            T result = update(_db);
            SaveUnderLock();
            return result;
        }
    }

    private void SaveUnderLock()
    {
        var tmp = _dbPath + ".tmp";
        using (var file = File.Create(tmp)) Xml.Serialize(file, _db);
        File.Move(tmp, _dbPath, overwrite: true);
    }

    public string SaveMedia(byte[] jpegBytes)
    {
        var mediaId = Guid.NewGuid().ToString("N");
        File.WriteAllBytes(Path.Combine(_dataDirectory, "media", mediaId + ".jpg"), jpegBytes);
        Update(db =>
        {
            db.MediaFiles.Add(new MediaRecord { MediaId = mediaId, FileName = mediaId + ".jpg", Mime = "image/jpeg" });
            return 0;
        });
        return mediaId;
    }

    public byte[]? ReadMedia(string mediaId)
    {
        if (!Guid.TryParse(mediaId, out _)) return null;
        var snapshot = Snapshot();
        var media = snapshot.MediaFiles.FirstOrDefault(x => x.MediaId == mediaId);
        if (media is null || media.FileName != mediaId + ".jpg") return null;
        var path = Path.Combine(_dataDirectory, "media", media.FileName);
        return File.Exists(path) ? File.ReadAllBytes(path) : null;
    }
}
