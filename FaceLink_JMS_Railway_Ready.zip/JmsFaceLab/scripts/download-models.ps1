# Run from PowerShell: powershell -ExecutionPolicy Bypass -File scripts/download-models.ps1
# Downloads open-source OpenCV Zoo models. Only needed for image analysis; no cloud calls at inference.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $root 'Models'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$files = @(
    @{
        Name = 'face_detection_yunet_2026may.onnx'
        Uri = 'https://media.githubusercontent.com/media/opencv/opencv_zoo/47534e27c9851bb1128ccc0102f1145e27f23f98/models/face_detection_yunet/face_detection_yunet_2026may.onnx'
        SHA256 = 'ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0'
    },
    @{
        Name = 'face_recognition_sface_2021dec.onnx'
        Uri = 'https://huggingface.co/opencv/opencv_zoo/resolve/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx'
        SHA256 = '0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79'
    }
)
foreach ($item in $files) {
    $path = Join-Path $dest $item.Name
    if (Test-Path $path) {
        $current = (Get-FileHash -Algorithm SHA256 $path).Hash.ToLowerInvariant()
        if ($current -eq $item.SHA256) { Write-Host "Already verified: $($item.Name)"; continue }
        Remove-Item $path -Force
    }
    Write-Host "Downloading $($item.Name) ..."
    Invoke-WebRequest -Uri $item.Uri -OutFile $path -MaximumRedirection 10
    $digest = (Get-FileHash -Algorithm SHA256 $path).Hash.ToLowerInvariant()
    if ($digest -ne $item.SHA256) {
        Remove-Item $path -Force
        throw "SHA256 verification failed for $($item.Name). Download discarded."
    }
    Write-Host "Verified $($item.Name)"
}
Write-Host 'Model files are ready. Run: dotnet run'
