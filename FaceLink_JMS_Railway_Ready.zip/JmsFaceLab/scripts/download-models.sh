#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p Models
fetch() {
  local name="$1" uri="$2" sha="$3"
  if [ -f "Models/$name" ] && echo "$sha  Models/$name" | sha256sum -c - >/dev/null 2>&1; then
    echo "Already verified: $name"; return
  fi
  curl --fail --location --retry 2 "$uri" --output "Models/$name"
  echo "$sha  Models/$name" | sha256sum -c - || { rm -f "Models/$name"; echo 'Checksum mismatch' >&2; exit 1; }
}
fetch face_detection_yunet_2026may.onnx 'https://media.githubusercontent.com/media/opencv/opencv_zoo/47534e27c9851bb1128ccc0102f1145e27f23f98/models/face_detection_yunet/face_detection_yunet_2026may.onnx' 'ebafce4e3c118d6554634be5c27ab333b4c047a9a8c3faf1d7cf93101c22f0f0'
fetch face_recognition_sface_2021dec.onnx 'https://huggingface.co/opencv/opencv_zoo/resolve/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx' '0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79'
echo 'Models verified. Start the application with dotnet run.'
