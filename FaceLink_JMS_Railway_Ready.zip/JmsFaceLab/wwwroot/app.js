'use strict';
const state = { people: [], submissions: [], batch: null, status: null, photo: null, preview: null, active: 'capture', modalFace: null, toastTimer: null };
const $ = selector => document.querySelector(selector);
const $$ = selector => Array.from(document.querySelectorAll(selector));
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const formatTime = value => { try { return new Date(value).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); } catch { return value; } };

async function api(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', ...options });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `${response.status}: ${response.statusText}`);
  return result;
}
function toast(message) {
  const element = $('#toast'); element.textContent = message; element.classList.add('visible');
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => element.classList.remove('visible'), 4200);
}
function setView(view) {
  if (!['capture','repository','batch','activity'].includes(view)) return;
  state.active = view;
  $$('.screen').forEach(x => x.classList.toggle('active', x.id === `view-${view}`));
  $$('[data-view]').forEach(x => x.classList.toggle('active', x.dataset.view === view));
  $('#sectionTitle').textContent = ({ capture: 'Photo intake', repository: 'Face repository', batch: 'JMS batch enrollment', activity: 'Submission history' })[view];
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
async function refresh() {
  try {
    const [status, people, submissions, batch] = await Promise.all([
      api('/api/status'), api('/api/people'), api('/api/submissions'), api('/api/batch')
    ]);
    Object.assign(state, { status, people, submissions, batch });
    renderStatus(); renderPeople(); renderSubmissions(); renderBatch(); renderHistory();
  } catch (error) { toast(`Unable to load demo data: ${error.message}`); }
}
function renderStatus() {
  const s = state.status; if (!s) return;
  $('#statPeople').textContent = s.people;
  $('#statEnrolled').textContent = s.enrolledPhotos;
  $('#modelBadge').textContent = s.modelsReady ? '● Face engine ready' : '● Models not installed';
  $('#modelBadge').classList.toggle('offline', !s.modelsReady);
  $('#engineAlert').hidden = s.modelsReady;
}
function renderPeople() {
  const search = $('#peopleSearch').value.toLowerCase().trim();
  const people = state.people.filter(p => (p.name + ' ' + p.personId + ' ' + p.bookingId).toLowerCase().includes(search));
  $('#repoCount').textContent = `${people.length} of ${state.people.length} records`;
  $('#peopleGrid').innerHTML = people.map(p => `<article class="person-card"><img loading="lazy" src="${esc(p.photoUrl)}" alt="Synthetic portrait for ${esc(p.name)}"><div><strong>${esc(p.name)}</strong><small>${esc(p.personId)}<br>${esc(p.bookingId || 'Field record')}</small><span class="status-chip ${p.enrolled ? 'yes' : ''}">${p.enrolled ? `${p.enrolled} face${p.enrolled > 1 ? 's' : ''} enrolled` : 'Not enrolled'}</span></div></article>`).join('') || '<div class="empty-state">No matching people found.</div>';
}
function faceHtml(face) {
  const candidates = face.candidates || [];
  return `<div class="face-result">
    <img src="${esc(face.photoUrl)}" alt="Detected face crop">
    <div class="face-detail"><strong>Detected face • ${esc(face.faceId.slice(-4))}</strong>
      <small>${candidates.length ? `${candidates.length} potential repository candidate${candidates.length !== 1 ? 's' : ''}` : 'No candidate above review cutoff. Identity unknown.'}</small>
      ${candidates.map(c => `<div class="candidate-row"><img src="${esc(c.portraitUrl)}" alt="Enrolled candidate portrait"><div><span class="candidate-name">${esc(c.name)}</span><small>${esc(c.personId)} • Candidate only</small></div><span class="score" title="Cosine similarity, not confidence">${Number(c.similarity).toFixed(3)}</span></div>`).join('')}
      <button class="review-btn" data-action="enroll-face" data-face="${esc(face.faceId)}" data-photo="${esc(face.photoUrl)}" data-candidate="${candidates[0] ? esc(candidates[0].personId) : ''}">${candidates.length ? 'Review candidate / enroll' : 'Create field record / enroll'} ↗</button>
    </div></div>`;
}
function renderSubmissions() {
  const entries = [...state.submissions].slice(0, 8).reverse();
  $('#chatStream').innerHTML = `<div class="bot-message"><div class="bot-avatar">✧</div><div class="bot-bubble"><strong>Start a new submission</strong><p>Take or upload a photo of one or more people. I'll extract faces and show possible candidates from the enrolled repository. You control any identity link.</p><div class="guidance-pills"><span>01 Capture</span><span>02 Review</span><span>03 Enroll</span></div></div></div>` +
    entries.map(s => `<div class="user-message"><div class="user-bubble"><img loading="lazy" src="${esc(s.photoUrl)}" alt="Submitted photo"><p>${esc(s.note || 'Photo submitted for candidate review')} · ${formatTime(s.createdAt)}</p></div></div>
      <div class="result-bubble"><h4>${s.faces.length ? `${s.faces.length} ${s.faces.length === 1 ? 'face' : 'faces'} extracted` : esc(s.status)}</h4><p class="result-subtitle">Submission ${esc(s.submissionId)} · ${esc(s.status)}</p>
      ${s.faces.length ? `<div class="face-results">${s.faces.map(faceHtml).join('')}</div>` : `<p class="muted">${s.status === 'Pending models' ? 'Install local ONNX models, then reanalyze this photo.' : 'Try a clear, front-facing photo with adequate lighting.'}</p>`}
      ${s.status === 'Pending models' && state.status?.modelsReady ? `<button class="review-btn" data-action="reanalyze" data-id="${esc(s.submissionId)}">Analyze now</button>` : ''}</div>`).join('');
  $('#chatStream').scrollTop = $('#chatStream').scrollHeight;
}
function renderHistory() {
  $('#historyList').innerHTML = state.submissions.length ? state.submissions.map(s => `
    <article class="history-card"><img src="${esc(s.photoUrl)}" alt="Original submitted photo"><div class="history-info"><strong>${esc(s.note || 'Photo submission')}</strong><p>${esc(s.submissionId)} · ${formatTime(s.createdAt)}</p><span class="status-chip ${s.faces.length ? 'yes' : ''}">${s.faces.length} detected · ${esc(s.status)}</span></div>
    ${s.status === 'Pending models' ? `<button class="review-btn" data-action="reanalyze" data-id="${esc(s.submissionId)}">Analyze</button>` : `<button class="review-btn" data-action="open-submission" data-id="${esc(s.submissionId)}">View in intake</button>`}</article>`).join('') : '<div class="empty-state">No submissions yet. Add a photo in the Photo intake screen.</div>';
}
function renderBatch() {
  const q = state.batch || { items:[], total:0, ready:0, possibleDuplicates:0, alreadyEnrolled:0, noFace:0 };
  $('#batchSummary').innerHTML = [
    [q.total,'Photos scanned'],[q.ready,'Ready for review'],[q.possibleDuplicates,'Possible duplicates'],[q.alreadyEnrolled,'Already enrolled']
  ].map(([number,label]) => `<div class="summary-box"><strong>${number}</strong><small>${label}</small></div>`).join('');
  $('#batchHelp').textContent = q.total ? `${q.ready} candidate records eligible for officer-reviewed bulk enrollment · ${q.noFace} need a clearer image` : 'Run a scan to create the queue.';
  $('#batchList').innerHTML = q.items.length ? q.items.map(item => `<div class="batch-item"><input aria-label="Select ${esc(item.name)}" class="batch-check" type="checkbox" value="${esc(item.personId)}" ${item.status !== 'ready' ? 'disabled' : ''}><img loading="lazy" src="${esc(item.photoUrl)}" alt="Synthetic demo portrait"><div><div class="item-title">${esc(item.name)}</div><div class="item-subtitle">${esc(item.personId)}${item.possiblePersonId ? ` · Similar to ${esc(item.possiblePersonId)} (${Number(item.similarity).toFixed(3)})` : ''}</div></div><div class="item-status"><span class="status-chip ${item.status === 'already-enrolled' ? 'yes' : item.status === 'possible-duplicate' ? 'duplicate' : ''}">${esc(item.status.replaceAll('-', ' '))}</span></div></div>`).join('') : '<div class="empty-state">Batch scan results will appear here. Scanning does not enroll anyone.</div>';
  $('#selectAllReady').checked = false; updateSelectedCount();
}
function updateSelectedCount() {
  const count = $$('.batch-check:checked').length;
  const button = $('#enrollSelected'); button.textContent = `Enroll selected (${count})`; button.disabled = count === 0;
}
async function preparePhoto(file) {
  if (!file) return;
  try {
    const url = URL.createObjectURL(file);
    const image = await new Promise((resolve, reject) => {
      const img = new Image(); img.onload = () => resolve(img); img.onerror = () => reject(new Error('Your device could not decode this photo. Choose a JPEG or PNG.')); img.src = url;
    });
    const scale = Math.min(1, 1600 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas'); canvas.width = Math.max(1, Math.round(image.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('JPEG conversion failed.')), 'image/jpeg', .87));
    URL.revokeObjectURL(url);
    if (state.preview) URL.revokeObjectURL(state.preview);
    state.photo = new File([blob], 'field-submission.jpg', { type: 'image/jpeg' });
    state.preview = URL.createObjectURL(blob);
    $('#selectedPreview').src = state.preview;
    $('#selectedName').textContent = file.name || 'New photo';
    $('#selectedPhoto').hidden = false;
    toast('Photo is ready to submit.');
  } catch (error) { toast(error.message); }
}
function clearPhoto() {
  if (state.preview) URL.revokeObjectURL(state.preview);
  state.photo = state.preview = null;
  $('#selectedPhoto').hidden = true;
  $('#cameraInput').value = ''; $('#galleryInput').value = '';
}
async function sendPhoto(event) {
  event.preventDefault();
  if (!state.photo) return toast('Take or choose a photograph first.');
  const submit = $('#submitPhoto'); submit.disabled = true; submit.textContent = 'Analyzing…';
  try {
    const form = new FormData(); form.append('photo', state.photo); form.append('note', $('#photoNote').value);
    const result = await api('/api/submissions', { method:'POST', body:form });
    clearPhoto(); $('#photoNote').value = '';
    await refresh(); setView('capture');
    toast(result.faces?.length ? `${result.faces.length} face(s) extracted; review candidate records.` : `Submission saved with status: ${result.status}`);
  } catch (error) { toast(error.message); }
  finally { submit.disabled = false; submit.innerHTML = 'Submit photo <span>↗</span>'; }
}
function openEnroll(faceId, photoUrl, candidateId) {
  state.modalFace = faceId;
  const select = $('#enrollPerson');
  select.innerHTML = '<option value="">New unverified field record</option>' + state.people.map(p => `<option value="${esc(p.personId)}">${esc(p.name)} (${esc(p.personId)})</option>`).join('');
  select.value = candidateId && state.people.some(p => p.personId === candidateId) ? candidateId : '';
  $('#modalPortrait').src = photoUrl;
  $('#enrollName').value = '';
  $('#confirmReview').checked = false;
  updateEnrollName();
  $('#enrollDialog').showModal();
}
function updateEnrollName() { $('#newNameLabel').hidden = !!$('#enrollPerson').value; }
async function submitEnroll(event) {
  event.preventDefault();
  const button = $('#confirmEnroll'); button.disabled = true;
  try {
    const personId = $('#enrollPerson').value || null;
    const result = await api('/api/enroll', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({
      faceId:state.modalFace, personId, name:$('#enrollName').value, reviewedBy:$('#reviewedBy').value, operatorReviewed:$('#confirmReview').checked
    }) });
    $('#enrollDialog').close(); await refresh(); toast(`Face enrolled to ${result.name}. Record remains subject to verification.`);
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; }
}
async function scanBatch() {
  const btn = $('#scanBatch'); btn.disabled = true; btn.textContent = 'Scanning local JMS photos…';
  try {
    await api('/api/batch/scan', { method:'POST' });
    await refresh(); toast('JMS scan complete. Review ready and possible-duplicate records.');
  } catch (error) { toast(error.message); }
  finally { btn.disabled = false; btn.innerHTML = 'Scan JMS photos <span>↗</span>'; }
}
async function enrollSelected() {
  const selected = $$('.batch-check:checked').map(e => e.value);
  if (!selected.length) return;
  if (!window.confirm(`You selected ${selected.length} records. Confirm you have reviewed these JMS headshots and authorize batch enrollment. Potential duplicates will remain excluded.`)) return;
  const name = window.prompt('Enter the name of the operator performing this review:', 'Demo Officer');
  if (!name || !name.trim()) return;
  const button = $('#enrollSelected'); button.disabled = true; button.textContent = 'Enrolling…';
  try {
    const result = await api('/api/batch/enroll', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({personIds:selected, reviewedBy:name, operatorReviewed:true}) });
    await refresh(); toast(`${result.enrolled} photos enrolled; ${result.skipped} held for further review.`);
  } catch (error) { toast(error.message); }
  finally { updateSelectedCount(); }
}
async function loadGroupTest() {
  try {
    const response = await fetch('/demo/sample-group.jpg');
    if (!response.ok) throw new Error('Sample group photo not found.');
    const blob = await response.blob();
    await preparePhoto(new File([blob], 'sample-group.jpg', { type:'image/jpeg' }));
    setView('capture');
  } catch (error) { toast(error.message); }
}
async function reanalyze(id) {
  try { const s = await api(`/api/submissions/${encodeURIComponent(id)}/analyze`, { method:'POST' }); await refresh(); setView('capture'); toast(`${s.faces.length} faces extracted.`); }
  catch (error) { toast(error.message); }
}
function wireEvents() {
  $$('[data-view]').forEach(btn => btn.addEventListener('click', () => setView(btn.dataset.view)));
  $('#peopleSearch').addEventListener('input', renderPeople);
  $('#takePhoto').addEventListener('click', () => $('#cameraInput').click());
  $('#choosePhoto').addEventListener('click', () => $('#galleryInput').click());
  $('#cameraInput').addEventListener('change', e => preparePhoto(e.target.files?.[0]));
  $('#galleryInput').addEventListener('change', e => preparePhoto(e.target.files?.[0]));
  $('#removePhoto').addEventListener('click', clearPhoto);
  $('#uploadForm').addEventListener('submit', sendPhoto);
  $('#scanBatch').addEventListener('click', scanBatch);
  $('#enrollSelected').addEventListener('click', enrollSelected);
  $('#selectAllReady').addEventListener('change', event => { $$('.batch-check:not(:disabled)').forEach(c => c.checked = event.target.checked); updateSelectedCount(); });
  $('#batchList').addEventListener('change', updateSelectedCount);
  $('#enrollForm').addEventListener('submit', submitEnroll);
  $('#closeModal').addEventListener('click', () => $('#enrollDialog').close());
  $('#enrollPerson').addEventListener('change', updateEnrollName);
  $('#demoPhotoRow').addEventListener('click', async event => {
    const image = event.target.closest('img'); if (!image) return;
    try { const response = await fetch(image.src); const blob = await response.blob(); await preparePhoto(new File([blob], `demo-${image.src.split('/').pop()}`, { type:'image/jpeg' })); }
    catch (error) { toast(error.message); }
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-action]'); if (!button) return;
    const { action } = button.dataset;
    if (action === 'show-repository') setView('repository');
    if (action === 'load-group-test') loadGroupTest();
    if (action === 'open-submission') setView('capture');
    if (action === 'reanalyze') reanalyze(button.dataset.id);
    if (action === 'enroll-face') openEnroll(button.dataset.face, button.dataset.photo, button.dataset.candidate);
  });
}
wireEvents();
refresh();
